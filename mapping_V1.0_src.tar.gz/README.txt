Author:
Nathan Yan

Version:
Rudimentary SLAM Mapping - v1.0

Date:
10/23/2023

General Instructions
1) Download mapping_V1.0_src.tar.gz
2) Use command "tar -xvzf Chess_Alpha_src.tar.gz"
3) While inside parent directory, type "make"
4) Afterwards, type "./bin/mapping" to run the executable


